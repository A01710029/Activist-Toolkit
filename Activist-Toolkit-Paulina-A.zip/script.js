/* .js files add interaction to your website */

//fact generator code - film
var filmFactList = [
  "Only about 4 out of 10 lead actors, 2.6 out of 10 writers, and 2.5 out of 10 directors in films are people of color.",/*0*/
  "71.2% of films with minority leads in 2020 had reduced budgets.",/*1*/
  "Films directed by women have about 30% to 40% more diverse casting than those directed by men.",/*3*/
  "Films directed by people of color have about 66% more diverse casting than those directed by white people.",/*4*/
  "Films written by women have about 60% more diverse casts than those written by men.",/*5*/
  "Only 10% of films that win awards are directed by women or people of color.",/*6*/
  "In 2019, not a single movie starring a person of color won an Oscar.", /*7*/
  "Having 10% or less minority casting increases your chances of winning an Oscar.",/*8*/
  "Only 3% of female leads are older than 45 years old.",/*9*/
  "78% of films feature no LGBTQ characters, and of those LGBTQ characters, only 23% are minorities.",/*10*/
  "Only 2 films in 2019 featured a LGBTQ lead.",/*11*/
  "Only 2.3% of speaking characters are disabled, and of those characters, a vast majority are white men over 40."/*12*/];

var filmFact = document.getElementById("film-fact");
var filmButton = document.getElementById("film-button");
var count = 0;

filmButton.addEventListener("click", displayFilmFact);

function displayFilmFact(){
  filmFact.innerHTML = filmFactList[count];
  count++;
  if (count == filmFactList.length){
    count = 0;
  }
}

//fact generator code - tv
var tvFactList = [
  "Only 24% of credited writers in TV shows in 2020 were minorities.",/*0*/
  "Only 21.8% of episodes in 2020 were directed by minorities.",/*1*/
  "Of all female characters in TV in 2020, 66% were white, 20% were black, 8% were Asian, and 5% were Latina.",/*2*/
  "TV shows with at least one female creator feature more female characters and hire more women behind-the-scenes than shows with male-only creative teams.",/*3*/
  "Only about 28% of TV creators are women.",/*4*/
  "94% of TV programs have no women hired behind-the-scenes.",/*5*/
  "The percentage of speaking Latin characters in TV has remained at 5% for the last decade.",/*6*/
  "Only 24% of TV shows have sole minority protagonists.",/*7*/
  "Only 2% of shows employed 14 or more minorities in major roles behind-the-scenes, compared to 51% of shows employing 14 or more men.",/*8*/
  "52% of female characters in TV have home-oriented roles, like housewives and mothers.",/*9*/
  "Only about 36% of broadcast network producers are women.",/*10*/
  "57% of programs with at least 1 woman creator have lead female protagonists.",/*11*/
  "The percentage of speaking Asian characters in TV has increased one point in the last decade."/*12*/];

var tvFact = document.getElementById("tv-fact");
var tvButton = document.getElementById("tv-button");
var count = 0;

tvButton.addEventListener("click", displayTvFact);

function displayTvFact(){
  tvFact.innerHTML = tvFactList[count];
  count++;
  if (count == tvFactList.length){
    count = 0;
  }
}

//fact generator code - animation
var animationFactList = [
  "Only 3% of animated films and 12% of animated shows featured a female protagonist of color.",/*0*/
  "Only 1% of directors of animated films and 2% of directors of animated shows are women of color.",/*1*/
  "3% of animated films and 13% of animated TV shows have female directors.",/*2*/
  "90% of minorities are never promoted in their careers in animation.",/*3*/
  "The only women of color that directed animated projects in 2020 were Asian.",/*4*/
  "The	average gender	ratio	of	men	to	women	in animation studios	is	8.5	to	1.",/*5*/
  "47% of all animated shorts that go to top	film	festivals	have	at	least	one	female	creator.",/*6*/
  "50% of minorities report facing discrimination in their working environment.",/*7*/
  "7% of leadership positions are held by women of color.",/*8*/
  "93% of Heads of Story in major studios are men.",/*9*/
  "17% of animated TV shows have female showrunners.",/*10*/
  "In 2017, over 200 animators from various studios wrote an open letter denouncing the constant sexual harrassment they faced - a movement known as #MeToon.",/*11*/
  "There have been no increases to the percentage of female producers in animation in the past 12 years."];/*12*/


var animationFact = document.getElementById("animation-fact");
var animationButton = document.getElementById("animation-button");
var count = 0;

animationButton.addEventListener("click", displayAnimationFact);

function displayAnimationFact(){
  animationFact.innerHTML = animationFactList[count];
  count++;
  if (count == animationFactList.length){
    count = 0;
  }
}
